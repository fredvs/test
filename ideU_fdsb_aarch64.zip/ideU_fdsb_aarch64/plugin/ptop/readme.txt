ptop is a more or less configurable source beautifier  for pascal  sources,
and specially the ones supported by FPC (which are more or less Turbo Pascal or Delphi 2.0 compatible).

ptop  belongs  to  the  FPC utils package.

The writer of the program is Michael Van Canneyt.

The program is a modernized (OOP, Streams,  Delphi  extensions) version based on a program by Peter Grogono,
who in turn based his program on a Pascal pretty-printer written by Ledgard, Hueras, and Singer.
See SIGPLAN Notices, Vol.12, No. 7, July 1977, pages  101-105,  and  PP.DOC/HLP.
This version of PP developed under Pascal/Z V4.0 or later.
Very minor modifications for Turbo Pascal made by  Willett Kempton  March 1984 and Oct 84.
Runs under 8-bit Turbo or 16-bit Turbo. 
Toad Hall tweak, rewrite for TP 5,  28  Nov  89
