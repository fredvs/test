sak : Speecher Assistive Kit. 

sak uses the PortAudio and eSpeak Open Source Libraries.

Fred van Stappen
fiens@hotmail.com


