Here how to transform a Lazarus lpi project into a ideU prj:

1) Copy lazarus.prj and paste it in same directory of your lpi project.
(example myproject.lpi).
2) Rename it with the same name as the name of lpi.
   Example: myproject.prj for myproject.lpi
3) Load it with ideU, compile it, run it.
