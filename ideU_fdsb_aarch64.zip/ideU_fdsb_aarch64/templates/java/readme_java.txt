Here how to compile a Java project:

2) Copy java.prj and paste it in same directory of your java file.
(example myproject.java).
4) Rename it with the same name as the name of java file.
   Example: myproject.prj for myproject.java
5) Load it with iideU, compile it, run it.
