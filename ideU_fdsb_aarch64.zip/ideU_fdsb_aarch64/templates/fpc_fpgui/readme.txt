
- fpg_single.prj ==> fpGUI program on one single file.

- fpg_units.prj ==> fpGUI program with main program file and unit/form file.
